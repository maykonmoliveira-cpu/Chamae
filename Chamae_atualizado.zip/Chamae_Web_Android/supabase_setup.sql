-- Chamaê: estrutura inicial para Supabase
-- Execute no SQL Editor do projeto rteeynlktogwjbjxezwr.
-- O script é idempotente: usa IF NOT EXISTS / CREATE OR REPLACE.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'cliente' check (role in ('cliente','prestador')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.providers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete set null,
  name text not null,
  category text not null,
  area text,
  rating numeric(2,1) not null default 5.0,
  half_day_price numeric(10,2) not null default 0,
  full_day_price numeric(10,2) not null default 0,
  about text,
  available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references auth.users(id) on delete cascade,
  provider_id uuid references public.providers(id) on delete set null,
  provider_name text not null,
  service_category text not null,
  duration text not null,
  service_date date,
  notes text,
  base_amount numeric(10,2) not null,
  tip_amount numeric(10,2) not null default 0,
  total_amount numeric(10,2) not null,
  status text not null default 'Solicitação enviada',
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.providers enable row level security;
alter table public.bookings enable row level security;
alter table public.messages enable row level security;

-- Cada usuário pode ler e alterar apenas o próprio perfil.
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Catálogo público de prestadores disponíveis; apenas o dono altera o próprio cadastro.
drop policy if exists "providers_public_read" on public.providers;
create policy "providers_public_read" on public.providers for select to anon, authenticated using (available = true or user_id = auth.uid());
drop policy if exists "providers_owner_insert" on public.providers;
create policy "providers_owner_insert" on public.providers for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "providers_owner_update" on public.providers;
create policy "providers_owner_update" on public.providers for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Cliente vê/cria suas solicitações. Prestador vê solicitações dirigidas ao seu cadastro.
drop policy if exists "bookings_participant_read" on public.bookings;
create policy "bookings_participant_read" on public.bookings for select to authenticated
using (client_id = auth.uid() or exists (select 1 from public.providers p where p.id = provider_id and p.user_id = auth.uid()));
drop policy if exists "bookings_client_insert" on public.bookings;
create policy "bookings_client_insert" on public.bookings for insert to authenticated with check (client_id = auth.uid());
drop policy if exists "bookings_participant_update" on public.bookings;
create policy "bookings_participant_update" on public.bookings for update to authenticated
using (client_id = auth.uid() or exists (select 1 from public.providers p where p.id = provider_id and p.user_id = auth.uid()))
with check (client_id = auth.uid() or exists (select 1 from public.providers p where p.id = provider_id and p.user_id = auth.uid()));

-- Somente participantes da solicitação podem ler/enviar mensagens.
drop policy if exists "messages_participant_read" on public.messages;
create policy "messages_participant_read" on public.messages for select to authenticated
using (exists (select 1 from public.bookings b left join public.providers p on p.id=b.provider_id where b.id=booking_id and (b.client_id=auth.uid() or p.user_id=auth.uid())));
drop policy if exists "messages_participant_insert" on public.messages;
create policy "messages_participant_insert" on public.messages for insert to authenticated
with check (sender_id=auth.uid() and exists (select 1 from public.bookings b left join public.providers p on p.id=b.provider_id where b.id=booking_id and (b.client_id=auth.uid() or p.user_id=auth.uid())));

-- Prestadores demonstrativos do MVP. Remova-os quando cadastrar profissionais reais.
insert into public.providers (name,category,area,rating,half_day_price,full_day_price,about,available)
select v.name,v.category,v.area,v.rating,v.half_day_price,v.full_day_price,v.about,true
from (values
 ('Ana Serviços','Diarista','América',4.9,120,200,'Limpeza residencial e organização.'),
 ('Carlos Eletricista','Eletricista','Centro',4.8,160,280,'Instalações e pequenos reparos.'),
 ('Marina Nails','Manicure','Atiradores',5.0,90,150,'Manicure, pedicure e cuidados.'),
 ('João Hidráulica','Encanador','Costa e Silva',4.9,150,260,'Reparos hidráulicos e instalações.')
) as v(name,category,area,rating,half_day_price,full_day_price,about)
where not exists (select 1 from public.providers p where p.name=v.name and p.category=v.category);
