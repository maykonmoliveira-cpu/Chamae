-- Chamae: inserir prestadores demonstrativos no catalogo.
-- Seguro para executar mais de uma vez: evita duplicar por nome + categoria.
-- Execute no projeto Supabase rteeynlktogwjbjxezwr.

insert into public.providers
  (name, category, area, rating, half_day_price, full_day_price, about, available)
select v.name, v.category, v.area, v.rating, v.half_day_price,
       v.full_day_price, v.about, true
from (values
  ('Ana Serviços','Diarista','América',4.9,120,200,'Limpeza residencial e organização.'),
  ('Carlos Eletricista','Eletricista','Centro',4.8,160,280,'Instalações e pequenos reparos.'),
  ('Marina Nails','Manicure','Atiradores',5.0,90,150,'Manicure, pedicure e cuidados.'),
  ('João Hidráulica','Encanador','Costa e Silva',4.9,150,260,'Reparos hidráulicos e instalações.')
) as v(name, category, area, rating, half_day_price, full_day_price, about)
where not exists (
  select 1 from public.providers p
  where p.name = v.name and p.category = v.category
);

select id, name, category, area, available
from public.providers
order by name;
