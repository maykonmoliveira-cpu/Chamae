# Chamaê — pacote Web/Android com integração inicial Supabase

## Projeto Supabase configurado
- Project ID: `rteeynlktogwjbjxezwr`
- URL base: `https://rteeynlktogwjbjxezwr.supabase.co`
- O app usa a chave pública `sb_publishable` fornecida pelo proprietário. Nunca coloque `service_role` ou `sb_secret` no cliente.

## O que está conectado no código
- Supabase JS v2 via CDN.
- Cadastro, login e logout por e-mail/senha.
- Criação/atualização do perfil básico em `public.profiles`.
- Criação de pedidos em `public.bookings` para usuário autenticado.
- Inserção de mensagens em `public.messages` para usuário autenticado.

## Banco de dados
1. As tabelas `profiles`, `providers`, `bookings` e `messages` foram criadas no projeto, conforme confirmação do proprietário no SQL Editor.
2. Execute `seed_demo_providers.sql` no SQL Editor para inserir os quatro prestadores demonstrativos. O script evita duplicações por nome e categoria.
3. O arquivo `supabase_setup.sql` contém a estrutura e políticas RLS usadas como referência. Como as tabelas já foram criadas, não execute alterações adicionais sem conferir o schema atual.

## Limitações conhecidas — não publicar como produção ainda
- Os prestadores exibidos no app ainda são dados demonstrativos embutidos no HTML; o SQL de seed cria registros correspondentes no banco para permitir associar pedidos.
- O chat grava mensagens, mas não carrega histórico nem usa Realtime.
- A mudança de status, cancelamentos, avaliações, favoritos e histórico ainda não estão totalmente persistidos no banco.
- O fluxo completo de cadastro/edição de perfil de prestador não está implementado.
- Não há pagamentos reais, notificações push nem validação de disponibilidade.
- As políticas RLS são uma base inicial e precisam de revisão de segurança antes de receber dados reais.

## Executar Web
Requer Node.js 20 ou superior:

```bash
npm install
npm run web
```

## Android
Requer Android Studio e SDK configurados:

```bash
npm install
npx cap sync android
npx cap open android
```

## Teste inicial recomendado
- Confirmar as quatro tabelas no schema `public`.
- Executar `seed_demo_providers.sql` e confirmar que aparecem quatro prestadores.
- Hospedar a pasta `www` em HTTPS.
- Testar cadastro com um e-mail de teste, confirmar e-mail se exigido, entrar e criar um pedido.
- Não usar dados pessoais ou pagamentos reais até concluir a revisão de segurança.
